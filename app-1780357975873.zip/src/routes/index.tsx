import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState, useCallback } from 'react'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)

  const tokens = [
    {
      symbol: '9IR',
      name: 'Core Liquidity Token',
      address: '9ireMXEb32ZSitkkEuVx4eJVjPhUJ8Qd7H96Sbr9rqZk',
      description: 'Core liquidity and activation layer of the 9Flow ecosystem',
      gradient: 'from-purple-500/20 to-cyan-500/20',
      borderGlow: 'shadow-[0_0_20px_rgba(168,85,247,0.15)]',
    },
    {
      symbol: '9flow',
      name: 'Dynamic Flow Engine',
      address: 'FLowyPaxVx6bCWPRSiF8ubKF7jm6DnS3UJ1MQ4ZTLWLC',
      description: 'Dynamic flow engine powering ecosystem movement and velocity',
      gradient: 'from-cyan-500/20 to-emerald-500/20',
      borderGlow: 'shadow-[0_0_20px_rgba(6,182,212,0.15)]',
    },
    {
      symbol: '9F',
      name: 'Infinity Coordination Token',
      address: '9iNFPxPDLPbogsa2qidWbSGhdTU3pA4bTMM1uRxi7vvC',
      description: 'Infinity coordination token linking value across the ecosystem',
      gradient: 'from-emerald-500/20 to-purple-500/20',
      borderGlow: 'shadow-[0_0_20px_rgba(34,197,94,0.15)]',
    },
  ]

  const copyToClipboard = useCallback(
    async (address: string, index: number) => {
      try {
        await navigator.clipboard.writeText(address)
        setCopiedIndex(index)
        setTimeout(() => setCopiedIndex(null), 2000)
      } catch {
        const textarea = document.createElement('textarea')
        textarea.value = address
        document.body.appendChild(textarea)
        textarea.select()
        document.execCommand('copy')
        document.body.removeChild(textarea)
        setCopiedIndex(index)
        setTimeout(() => setCopiedIndex(null), 2000)
      }
    },
    [],
  )

  return (
    <div className="relative min-h-screen bg-[#05050A] text-white overflow-hidden">
      <ParticlesBackground />
      <div className="fixed inset-0 grid-bg pointer-events-none z-[1]" />
      <div className="fixed top-1/4 left-1/4 w-[600px] h-[600px] rounded-full bg-purple-600/5 blur-[120px] pointer-events-none z-[1]" />
      <div className="fixed bottom-1/4 right-1/4 w-[500px] h-[500px] rounded-full bg-cyan-600/5 blur-[100px] pointer-events-none z-[1]" />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-emerald-600/3 blur-[150px] pointer-events-none z-[1]" />

      <div className="relative z-10">
        <nav className="sticky top-0 z-50 backdrop-blur-xl bg-[#05050A]/80 border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center text-xs font-bold">
                9
              </div>
              <span className="text-lg font-bold gradient-text">9Flow</span>
            </div>
            <a
              href="https://solscan.io"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              Solscan ↗
            </a>
          </div>
        </nav>

        <HeroSection />

        {/* Token Ecosystem */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <Reveal>
            <div className="text-center mb-16">
              <h2 className="text-4xl sm:text-5xl font-bold mb-4">
                <span className="gradient-text">Token Ecosystem</span>
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Three interconnected tokens powering the 9Flow network — each with a distinct role in the ecosystem's flow of value.
              </p>
            </div>
          </Reveal>

          <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
            {tokens.map((token, index) => (
              <Reveal key={token.symbol} delay={index * 0.15}>
                <div className={`gradient-border card-hover-glow rounded-2xl p-[1px] ${token.borderGlow}`}>
                  <div className="rounded-2xl bg-[#0a0a14] p-6 h-full flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${token.gradient} flex items-center justify-center text-lg font-bold`}>
                        {token.symbol}
                      </div>
                      <span className="text-xs text-gray-500 font-mono">SPL Token</span>
                    </div>
                    <h3 className="text-xl font-bold mb-1">{token.name}</h3>
                    <p className="text-gray-400 text-sm mb-6 flex-1">{token.description}</p>
                    <div className="mb-6">
                      <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Contract Address</p>
                      <p className="text-xs font-mono text-gray-300 break-all bg-white/5 rounded-lg p-3 border border-white/5">
                        {token.address}
                      </p>
                    </div>
                    <div className="flex gap-3 mt-auto">
                      <button
                        onClick={() => copyToClipboard(token.address, index)}
                        className="flex-1 px-4 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-medium transition-all duration-200 hover:border-white/20 active:scale-95"
                      >
                        {copiedIndex === index ? (
                          <span className="flex items-center justify-center gap-2 text-emerald-400">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            Copied!
                          </span>
                        ) : (
                          <span className="flex items-center justify-center gap-2">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                            </svg>
                            Copy Address
                          </span>
                        )}
                      </button>
                      <a
                        href={`https://solscan.io/token/${token.address}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2.5 rounded-lg bg-gradient-to-r from-purple-600/20 to-cyan-600/20 hover:from-purple-600/40 hover:to-cyan-600/40 border border-purple-500/20 hover:border-purple-500/40 text-sm font-medium transition-all duration-200 active:scale-95 whitespace-nowrap"
                      >
                        Solscan ↗
                      </a>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* Ecosystem Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <Reveal>
            <EcosystemDiagram />
          </Reveal>
          <Reveal delay={0.3}>
            <div className="text-center mt-16 max-w-3xl mx-auto">
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                <span className="gradient-text">A Living Network</span>
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                9Flow is not a single token system. It is a living network where
                value, liquidity, and utility circulate continuously between
                interconnected assets.
              </p>
            </div>
          </Reveal>
        </section>

        <StatsSection />
        <RoadmapSection />
        <FaqSection />

        <footer className="border-t border-white/5 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-6 h-6 rounded-md bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center text-[10px] font-bold">9</div>
              <span className="text-sm font-bold gradient-text">9Flow</span>
            </div>
            <div className="flex items-center justify-center gap-6 mb-4 text-sm">
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors">Whitepaper</a>
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors">Docs</a>
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors">GitHub</a>
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors">Twitter</a>
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors">Discord</a>
            </div>
            <p className="text-gray-500 text-sm">Flow Through Infinity. Built on Solana.</p>
          </div>
        </footer>
      </div>
    </div>
  )
}

/* ─── Particles Background ────── */
function ParticlesBackground() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const colors = [
      'rgba(168,85,247,0.6)',
      'rgba(6,182,212,0.6)',
      'rgba(34,197,94,0.4)',
      'rgba(168,85,247,0.3)',
      'rgba(6,182,212,0.4)',
    ]

    const particles: HTMLDivElement[] = []
    const count = 40

    for (let i = 0; i < count; i++) {
      const particle = document.createElement('div')
      particle.className = 'particle'
      const size = Math.random() * 4 + 1.5
      particle.style.width = `${size}px`
      particle.style.height = `${size}px`
      particle.style.left = `${Math.random() * 100}%`
      particle.style.background = colors[Math.floor(Math.random() * colors.length)]
      particle.style.animationDuration = `${Math.random() * 20 + 15}s`
      particle.style.animationDelay = `${Math.random() * 20}s`
      particle.style.boxShadow = `0 0 ${size * 2}px ${colors[Math.floor(Math.random() * colors.length)]}`
      container.appendChild(particle)
      particles.push(particle)
    }

    return () => particles.forEach((p) => p.remove())
  }, [])

  return <div ref={containerRef} className="particle-container" />
}

/* ─── Hero Section ────── */
function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex flex-col items-center justify-center px-4 pt-20 pb-16">
      <div className="relative mb-12 w-72 h-72 sm:w-80 sm:h-80">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500/30 to-cyan-500/30 animate-[pulse-glow_3s_ease-in-out_infinite] flex items-center justify-center">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-cyan-400 blur-sm" />
          </div>

          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 320 320">
            <circle cx="160" cy="160" r="108" fill="none" stroke="rgba(168,85,247,0.08)" strokeWidth="0.5" />
            <circle cx="160" cy="160" r="90" fill="none" stroke="rgba(6,182,212,0.06)" strokeWidth="0.5" />
          </svg>

          {/* Node 1 - Purple */}
          <div className="absolute w-full h-full animate-[orbit1-sm_8s_linear_infinite] sm:animate-[orbit1_8s_linear_infinite]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-purple-600/20 border border-purple-500/40 flex items-center justify-center animate-[pulse-node_3s_ease-in-out_infinite]">
                <div className="w-4 h-4 rounded-full bg-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.6)]" />
              </div>
              <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] text-purple-400 font-mono whitespace-nowrap">9IR</span>
            </div>
          </div>

          {/* Node 2 - Cyan */}
          <div className="absolute w-full h-full animate-[orbit2-sm_8s_linear_infinite] sm:animate-[orbit2_8s_linear_infinite]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-cyan-600/20 border border-cyan-500/40 flex items-center justify-center animate-[pulse-node_3s_ease-in-out_infinite_0.5s]">
                <div className="w-4 h-4 rounded-full bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.6)]" />
              </div>
              <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] text-cyan-400 font-mono whitespace-nowrap">9flow</span>
            </div>
          </div>

          {/* Node 3 - Green */}
          <div className="absolute w-full h-full animate-[orbit3-sm_8s_linear_infinite] sm:animate-[orbit3_8s_linear_infinite]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center animate-[pulse-node_3s_ease-in-out_infinite_1s]">
                <div className="w-4 h-4 rounded-full bg-emerald-500 shadow-[0_0_15px_rgba(34,197,94,0.6)]" />
              </div>
              <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] text-emerald-400 font-mono whitespace-nowrap">9F</span>
            </div>
          </div>
        </div>

        {/* SVG Flowing "9" */}
        <svg className="absolute inset-0 w-full h-full animate-[glow-pulse-soft_4s_ease-in-out_infinite]" viewBox="0 0 320 320" fill="none">
          <path d="M160 160 L160 45" stroke="url(#gradPurple)" strokeWidth="1.5" strokeDasharray="4 6" className="opacity-40">
            <animate attributeName="stroke-dashoffset" from="0" to="-100" dur="2s" repeatCount="indefinite" />
          </path>
          <path d="M160 160 L268 160" stroke="url(#gradCyan)" strokeWidth="1.5" strokeDasharray="4 6" className="opacity-40">
            <animate attributeName="stroke-dashoffset" from="0" to="-100" dur="2.5s" repeatCount="indefinite" />
          </path>
          <path d="M160 160 L52 160" stroke="url(#gradGreen)" strokeWidth="1.5" strokeDasharray="4 6" className="opacity-40">
            <animate attributeName="stroke-dashoffset" from="0" to="-100" dur="3s" repeatCount="indefinite" />
          </path>

          <path
            d="M180 100 C 200 100, 210 110, 210 130 C 210 150, 200 160, 180 160 C 155 160, 145 145, 140 120 C 135 95, 138 75, 155 55 C 172 35, 195 35, 215 50 C 240 68, 248 90, 248 120 C 248 155, 235 180, 210 200 C 185 220, 145 225, 110 215"
            stroke="url(#grad9)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none"
            className="drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]" strokeDasharray="400" strokeDashoffset="0"
          >
            <animate attributeName="stroke-dashoffset" from="400" to="0" dur="3s" begin="0s" fill="freeze" />
            <animate attributeName="stroke-dashoffset" from="0" to="400" dur="3s" begin="3s" fill="freeze" />
            <animate attributeName="opacity" from="1" to="0" dur="1s" begin="5.5s" fill="freeze" />
          </path>

          <path
            d="M180 100 C 200 100, 210 110, 210 130 C 210 150, 200 160, 180 160 C 155 160, 145 145, 140 120 C 135 95, 138 75, 155 55 C 172 35, 195 35, 215 50 C 240 68, 248 90, 248 120 C 248 155, 235 180, 210 200 C 185 220, 145 225, 110 215"
            stroke="url(#grad9Fade)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"
            className="opacity-60" strokeDasharray="6 8"
          >
            <animate attributeName="stroke-dashoffset" from="0" to="-100" dur="3s" repeatCount="indefinite" />
          </path>

          <defs>
            <linearGradient id="gradPurple" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#a855f7" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.2" />
            </linearGradient>
            <linearGradient id="gradCyan" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.8" />
            </linearGradient>
            <linearGradient id="gradGreen" x1="1" y1="0" x2="0" y2="0">
              <stop offset="0%" stopColor="#22c55e" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#22c55e" stopOpacity="0.8" />
            </linearGradient>
            <linearGradient id="grad9" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#a855f7" />
              <stop offset="50%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#22c55e" />
            </linearGradient>
            <linearGradient id="grad9Fade" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#a855f7" stopOpacity="0.5" />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#22c55e" stopOpacity="0.5" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <h1 className="text-6xl sm:text-7xl lg:text-8xl font-bold mb-4 glow-text tracking-tight">9Flow</h1>
      <p className="text-xl sm:text-2xl text-gray-300 mb-2 font-light tracking-widest uppercase">Flow Through Infinity.</p>
      <p className="text-sm sm:text-base text-gray-500 mb-10 max-w-md text-center">A unified Solana ecosystem of interconnected liquidity and innovation.</p>

      <div className="flex flex-col sm:flex-row gap-4">
        <a
          href="#ecosystem"
          className="btn-glow px-8 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-semibold text-sm tracking-wide border-0 shadow-[0_0_20px_rgba(168,85,247,0.3)] inline-flex items-center justify-center gap-2"
        >
          Explore Ecosystem
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </a>
        <a
          href="https://solscan.io"
          target="_blank"
          rel="noopener noreferrer"
          className="px-8 py-3.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-white font-semibold text-sm tracking-wide transition-all duration-200 backdrop-blur-sm inline-flex items-center justify-center gap-2"
        >
          View on Solscan
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
          </svg>
        </a>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-xs text-gray-600 tracking-widest uppercase">Scroll</span>
        <div className="w-5 h-8 rounded-full border border-white/10 flex justify-center pt-1.5">
          <div className="w-1 h-1.5 rounded-full bg-gradient-to-b from-purple-400 to-cyan-400 animate-bounce" />
        </div>
      </div>
    </section>
  )
}

/* ─── Ecosystem Diagram ────── */
function EcosystemDiagram() {
  return (
    <div className="relative w-full max-w-3xl mx-auto">
      <div className="relative flex items-center justify-center h-80 sm:h-96">
        <div className="relative w-64 h-64 sm:w-80 sm:h-80">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-purple-600/30 to-cyan-600/30 border border-white/5 flex items-center justify-center backdrop-blur-sm">
              <span className="text-lg sm:text-xl font-bold gradient-text">9Flow</span>
            </div>
          </div>

          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 320 320">
            <circle cx="160" cy="160" r="90" fill="none" stroke="rgba(168,85,247,0.1)" strokeWidth="0.5" strokeDasharray="4 4">
              <animateTransform attributeName="transform" type="rotate" from="0 160 160" to="360 160 160" dur="20s" repeatCount="indefinite" />
            </circle>
            <circle cx="160" cy="160" r="130" fill="none" stroke="rgba(6,182,212,0.08)" strokeWidth="0.5" strokeDasharray="3 6">
              <animateTransform attributeName="transform" type="rotate" from="360 160 160" to="0 160 160" dur="25s" repeatCount="indefinite" />
            </circle>
            <circle cx="160" cy="160" r="50" fill="none" stroke="rgba(34,197,94,0.06)" strokeWidth="0.5" strokeDasharray="2 5">
              <animateTransform attributeName="transform" type="rotate" from="0 160 160" to="360 160 160" dur="15s" repeatCount="indefinite" />
            </circle>
          </svg>

          <div className="absolute w-full h-full animate-[orbit1-sm_10s_linear_infinite] sm:animate-[orbit1_10s_linear_infinite]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-purple-600/30 to-purple-800/30 border border-purple-500/30 flex flex-col items-center justify-center backdrop-blur-sm">
                <span className="text-xs sm:text-sm font-bold text-purple-300">9IR</span>
                <span className="text-[8px] text-purple-500/60">LIQUIDITY</span>
              </div>
            </div>
          </div>

          <div className="absolute w-full h-full animate-[orbit2-sm_12s_linear_infinite] sm:animate-[orbit2_12s_linear_infinite]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-cyan-600/30 to-cyan-800/30 border border-cyan-500/30 flex flex-col items-center justify-center backdrop-blur-sm">
                <span className="text-xs sm:text-sm font-bold text-cyan-300">9flow</span>
                <span className="text-[8px] text-cyan-500/60">VELOCITY</span>
              </div>
            </div>
          </div>

          <div className="absolute w-full h-full animate-[orbit3-sm_14s_linear_infinite] sm:animate-[orbit3_14s_linear_infinite]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-emerald-600/30 to-emerald-800/30 border border-emerald-500/30 flex flex-col items-center justify-center backdrop-blur-sm">
                <span className="text-xs sm:text-sm font-bold text-emerald-300">9F</span>
                <span className="text-[8px] text-emerald-500/60">COORDINATION</span>
              </div>
            </div>
          </div>

          <div className="absolute inset-0">
            <div className="absolute w-2 h-2 rounded-full bg-purple-400/60 top-1/2 left-1/2 animate-ping" style={{ animationDuration: '2s' }} />
            <div className="absolute w-2 h-2 rounded-full bg-cyan-400/60 top-1/3 right-1/3 animate-ping" style={{ animationDuration: '2.5s', animationDelay: '0.5s' }} />
            <div className="absolute w-2 h-2 rounded-full bg-emerald-400/60 bottom-1/3 left-1/3 animate-ping" style={{ animationDuration: '3s', animationDelay: '1s' }} />
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── Stats Section ────── */
function StatsSection() {
  const ref = useRef<HTMLDivElement>(null)

  const stats = [
    { label: 'Total Liquidity', value: '$2.4M+', suffix: 'locked across all tokens', icon: '💰' },
    { label: 'Active Addresses', value: '8,420+', suffix: 'unique wallet interactions', icon: '👛' },
    { label: 'Ecosystem TVL', value: '$6.8M', suffix: 'total value in circulation', icon: '📊' },
    { label: 'Transactions', value: '127K+', suffix: 'on-chain 9Flow activity', icon: '⚡' },
  ]

  return (
    <section ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
      <Reveal>
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">Ecosystem by the Numbers</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Real-time metrics reflecting the growth and velocity of the 9Flow network.
          </p>
        </div>
      </Reveal>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {stats.map((stat, i) => (
          <Reveal key={stat.label} delay={i * 0.1}>
            <div className="gradient-border card-hover-glow rounded-2xl p-[1px]">
              <div className="rounded-2xl bg-[#0a0a14] p-6 text-center h-full">
                <span className="text-2xl mb-3 block">{stat.icon}</span>
                <p className="text-3xl sm:text-4xl font-bold mb-1 gradient-text">{stat.value}</p>
                <p className="text-sm text-gray-400 font-medium mb-1">{stat.label}</p>
                <p className="text-xs text-gray-600">{stat.suffix}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  )
}

/* ─── Roadmap Section ────── */
function RoadmapSection() {
  const phases = [
    {
      phase: 'Phase 1', title: 'Genesis Flow', status: 'completed' as const, date: 'Q1 2024',
      items: ['Token contract deployment & audit', 'Liquidity pool initialization', 'Community launch & initial marketing', '9IR core activation layer live'],
    },
    {
      phase: 'Phase 2', title: 'Ecosystem Expansion', status: 'completed' as const, date: 'Q2 2024',
      items: ['9flow velocity engine activation', 'Cross-token swap integration', 'Staking pools & yield farming', 'Partnership ecosystem onboarding'],
    },
    {
      phase: 'Phase 3', title: 'Infinity Coordination', status: 'active' as const, date: 'Q3 2024',
      items: ['9F coordination token launch', 'Multi-token governance framework', 'Advanced analytics dashboard', 'Automated liquidity routing'],
    },
    {
      phase: 'Phase 4', title: 'Autonomous Flow', status: 'upcoming' as const, date: 'Q4 2024',
      items: ['AI-powered flow optimization', 'Cross-chain bridge integration', 'Decentralized flow orchestration', 'Full ecosystem autonomy'],
    },
  ]

  return (
    <section id="ecosystem" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
      <Reveal>
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">Development Roadmap</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            The 9Flow ecosystem is evolving through four defined phases toward full autonomous flow.
          </p>
        </div>
      </Reveal>

      <div className="relative">
        <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-purple-500/40 via-cyan-500/40 to-emerald-500/40 md:-translate-x-px" />

        <div className="space-y-12 md:space-y-16">
          {phases.map((phase, i) => (
            <Reveal key={phase.phase} delay={i * 0.15}>
              <div className="relative flex flex-col md:flex-row gap-6 md:gap-12">
                <div
                  className="absolute left-6 md:left-1/2 top-1 w-3 h-3 -translate-x-1/2 rounded-full z-10"
                  style={{
                    background: phase.status === 'completed'
                      ? 'linear-gradient(135deg, #a855f7, #22c55e)'
                      : phase.status === 'active'
                      ? 'linear-gradient(135deg, #06b6d4, #a855f7)'
                      : 'rgba(255,255,255,0.15)',
                    boxShadow: phase.status === 'active'
                      ? '0 0 15px rgba(6,182,212,0.5), 0 0 30px rgba(168,85,247,0.3)'
                      : 'none',
                  }}
                />

                <div className={`w-full md:w-[calc(50%-2rem)] ${i % 2 === 0 ? '' : 'md:ml-auto'}`}>
                  <div className="gradient-border rounded-2xl p-[1px]">
                    <div className="rounded-2xl bg-[#0a0a14] p-6 sm:p-8">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-xs font-mono text-purple-400 tracking-widest">{phase.phase}</span>
                        <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                          phase.status === 'completed'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : phase.status === 'active'
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 animate-pulse'
                            : 'bg-white/5 text-gray-500 border border-white/10'
                        }`}>
                          {phase.status === 'completed' ? '✓ Completed' : phase.status === 'active' ? '◉ Active' : '○ Upcoming'}
                        </span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-bold mb-1 gradient-text">{phase.title}</h3>
                      <p className="text-xs text-gray-600 font-mono mb-4">{phase.date}</p>
                      <ul className="space-y-2.5">
                        {phase.items.map((item) => (
                          <li key={item} className="flex items-start gap-3 text-sm text-gray-300">
                            <span className={`mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                              phase.status === 'completed' ? 'bg-emerald-400' : phase.status === 'active' ? 'bg-cyan-400' : 'bg-gray-600'
                            }`} />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─── FAQ Section ────── */
function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs = [
    {
      q: 'What is 9Flow?',
      a: '9Flow is a unified Solana ecosystem composed of three interconnected tokens — 9IR, 9flow, and 9F. Each token serves a distinct role in creating a seamless network where liquidity, velocity, and coordination flow together. Think of it as a living financial network rather than a single token project.',
    },
    {
      q: 'How do the three tokens interact?',
      a: '9IR (Core Liquidity) acts as the foundational activation layer. 9flow (Dynamic Flow Engine) powers movement and transaction velocity across the ecosystem. 9F (Infinity Coordination) ties everything together, enabling cross-token value transfer and governance. Together they create a self-sustaining economic loop.',
    },
    {
      q: 'Where can I buy 9Flow tokens?',
      a: '9Flow tokens are available on decentralized exchanges within the Solana ecosystem. You can swap SOL for any of the three tokens. Always verify contract addresses on Solscan before trading — never trust unverified sources.',
    },
    {
      q: 'What makes 9Flow different from other ecosystems?',
      a: 'Unlike single-token ecosystems, 9Flow uses a three-token architecture where each asset has a specialized function. This creates natural liquidity flows, reduces single-point-of-failure risks, and enables more sophisticated economic coordination. It\'s designed as a complete financial nervous system, not just another token.',
    },
    {
      q: 'Is there a governance system?',
      a: 'Yes, governance is planned for Phase 3 of the roadmap. The 9F token will serve as the primary governance vehicle, allowing holders to vote on ecosystem parameters, liquidity allocations, and protocol upgrades. Cross-token weighted voting ensures all three communities have a voice.',
    },
  ]

  return (
    <section className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
      <Reveal>
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">Frequently Asked Questions</span>
          </h2>
          <p className="text-gray-400 text-lg">Everything you need to know about the 9Flow ecosystem.</p>
        </div>
      </Reveal>

      <div className="space-y-3">
        {faqs.map((faq, i) => (
          <Reveal key={i} delay={i * 0.08}>
            <div className="rounded-2xl border border-white/5 bg-[#0a0a14] overflow-hidden transition-all duration-300 card-hover-glow">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
              >
                <span className="text-sm sm:text-base font-medium text-gray-200">{faq.q}</span>
                <svg
                  className={`w-5 h-5 flex-shrink-0 text-gray-500 transition-transform duration-300 ${openIndex === i ? 'rotate-180' : ''}`}
                  fill="none" viewBox="0 0 24 24" stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div className={`overflow-hidden transition-all duration-400 ease-in-out ${openIndex === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                <div className="px-6 pb-5 pt-0 border-t border-white/5 mt-0">
                  <p className="text-sm text-gray-400 leading-relaxed pt-4">{faq.a}</p>
                </div>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  )
}

/* ─── Scroll Reveal Wrapper ────── */
function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => entry.target.classList.add('visible'), delay * 1000)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.1 },
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [delay])

  return (
    <div ref={ref} className="reveal" style={{ transitionDelay: `${delay}s` }}>
      {children}
    </div>
  )
}